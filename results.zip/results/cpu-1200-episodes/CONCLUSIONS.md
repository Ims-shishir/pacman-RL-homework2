# Conclusions from 1200 episodes

The trendline ecuation generated based on over 1200 episodes is the following:
y = 0,2275x + 190,56

This suggests that the number or episodes needed to achieve an average score of 1600 (equivalent to eating all the dots in the game (this does not count points added by eating ghosts) is 6200 episodes.

score	   AIPE	  episodes  FS

1601,06 = 0,2275 * 6200 + 190,56

AIPE: Average improvement per episode, the average of improvement in score that is earned by learning for one episode
FS: Free Score, the average score of a random agent with no learning algorithm

The top three best scores achieved are the following:
- 2680 points
- 2020 points
- 1900 points
